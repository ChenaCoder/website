# message_encryption
Basic message encryption using  my own encryption algorithm made in python.
Follow the instructions to encrypt or decrypt messages.
Can be run through exe or terminal(with python installed)
