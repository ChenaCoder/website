# number_game
Number guessing game made in python.
Use the given commands to run the game before you run out of questions and guesses.
