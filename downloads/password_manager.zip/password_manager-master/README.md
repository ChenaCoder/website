Password Manager made using Java, MySql, and a Swing GUI. *Will not work without creating your own database and adding it to the code.
