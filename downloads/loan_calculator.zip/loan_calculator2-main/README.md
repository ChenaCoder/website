Monthly loan payment claculator in c++. Can be run through exe or through command line. Enter the requested values to get your monthly loan payment.
