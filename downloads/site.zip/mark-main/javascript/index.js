

function menu(){ 
     var nav = document.querySelector('.nav');
     var navLinks = document.querySelectorAll('.nav a');
     nav.classList.toggle('nav-active')
}